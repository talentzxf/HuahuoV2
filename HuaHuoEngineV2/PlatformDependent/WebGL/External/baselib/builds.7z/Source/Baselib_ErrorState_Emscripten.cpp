#include "Source/Posix/Baselib_ErrorState_PosixApi.inl.h"

namespace platform
{
    using PosixApi::Baselib_ErrorState_Explain;
}

#include "Source/CProxy/Baselib_ErrorState_CProxy.inl.h"
